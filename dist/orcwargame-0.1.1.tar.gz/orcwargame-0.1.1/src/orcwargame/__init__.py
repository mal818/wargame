# -*- coding: utf-8 -*-
# @Time    :2021/3/8 14:57
# @Author  :Ma Liang
# @Email   :mal818@126.com
# @File    :__init__.py.py

import sys
import os
current_path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_path)
